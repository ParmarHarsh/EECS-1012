assert = chai.assert;

describe('Testing function counter() of Task 6', function () {

    it('Test 1: counter() returns 1 after 19 calls', function () {
        for (var k = 1; k <= 19; k++) counter();
        assert.equal(counter(), 1);
        resetValue();
    });

    /* TODO 1: write a test case to verify the counter returns 0 after 20 calls*/
    it('Test 2: counter() returns 0 after 20 calls', function () {
        for (var k = 1; k <= 20; k++) counter();
        assert.equal(counter(), 0);
        resetValue();
    });

    /* TODO 2: write a test case to verify the counter returns BOOM! after 21 calls*/
    it('Test 3: counter() returns BOOM! after 21 calls', function () {
        for (var k = 1; k <= 21; k++) counter();
        assert.equal(counter(), "BOOM!");
    });

    /* TODO 3: write a test case to verify the counter returns BOOM! for the follow up calls*/
    it('Test 4: counter() returns BOOM! for the follow up calls', function () {
        assert.equal(counter(), "BOOM!");
    });

});